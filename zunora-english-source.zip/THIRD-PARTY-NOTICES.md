# Third-party content

Font license texts are under web/fonts. Font families: Inter, Plus Jakarta Sans, IBM Plex Sans Arabic and Space Grotesk, SIL Open Font License.

Film clip attribution and license/version links are included with every scene in web/index.html. Blender Foundation open movies include Sprite Fright, Elephants Dream, Tears of Steel, Sintel and Cosmos Laundromat. Keep their attribution and comply with each scene license when redistributing.

Dictionary sources: https://github.com/first20hours/google-10000-english , https://github.com/open-dict-data/ipa-dict , https://freedict.org/ . Arabic glosses are derived from the Arabic-English dataset. Their distinct licenses require a separate distribution review before calling the whole project newly open-licensed. No license to the user's own project is granted by this package.

The preserved UI bundle includes React, React DOM and other existing bundled components. This is the editable deployed-code version, not the original unbundled component repository. Exact upstream dependency/license reconciliation is not yet complete. Do not claim a fully audited third-party licensing inventory.
