## Tester-feedback fixes, batch 31, 24 November 2026

Applied on top of the complete 137-chapter curriculum, all still private:
1. Browsing UI is English-only: reading/listening centre cards and level filters no longer show Arabic titles or topics; Arabic translations remain inside lessons and exercises. The private-app gate is fixed to English.
2. Listening exercises now start in "Listen & understand" mode: the transcript is hidden until the learner answers and checks, and no answer is marked before the learner chooses.
3. Speaking practice no longer echoes the learner's words live while the microphone is on; starting the microphone now stops any speech playback so the character cannot talk over the learner.
4. The third-conditional item "had had" was reviewed and is correct; unchanged.

Checks: qa-fix31.json (new), full batch30 regression rerun green, C1 exam QA rerun green.

## Curriculum batch 31, 24 November 2026

137 requested chapters are authored: all 38 A1 chapters (380 lessons), all 31 A2 chapters (310 lessons), all 29 B1 chapters (290 lessons), all 23 B2 chapters (230 lessons), and C1 chapters 1-16 (160 lessons). Original 80 legacy lessons retain their IDs. Total available: 1450 lessons. This is 1370 of 1,370 requested new lessons. Remaining requested chapters: 0.

There are 3283 authored lesson questions across 959 quizzes plus 411 vocabulary quizzes. Static checks cover all new lessons and exact chapter titles/order. Browser checks opened all 1370 new lesson routes. The final full sweep completed all 959 authored lesson quizzes and all 411 vocabulary quizzes. See qa-final-all-quizzes.json for full coverage. Persistence, original IDs, backup round trip and 17 tool routes passed with no browser/HTTP errors. Mobile reading, quiz feedback and chapter counts were inspected. See qa-batch31.json for exact scope.

A1, A2, B1, B2 and C1 each have a separately tested 20-question final exam: 70% pass, 100 XP on first pass only, badge and locally downloadable Zunora English Academy certificate. The certificate is an internal achievement record, not an externally accredited qualification. Guided speaking/writing tasks are self-practice, not automatic teacher assessment. Medical chapters teach communication only, not diagnosis, treatment or a personal diet. Fictional prices, schedules and policies are not current offers or advice.

This is a web/source update, not a rebuilt or device-tested Android APK. Native microphone, picker, TTS and PDF-download behavior remain untested on device. No external upload or deployment is performed.

# Zunora English

This is an editable web app plus a native Android WebView wrapper. No hosted builder account, developer API key, sign-in server, or paid service is required to build or open it.

## Run the website
Install Python 3, then run `python3 -m http.server 8080 --directory web` from this folder. Open http://localhost:8080. A newly built Android APK packages these web files and bundled clips/fonts/dictionary data; no updated APK is included in this source delivery. Website hosting is optional.

## Build Android
Install a JDK (17 tested) and the Android SDK platform and build-tools. The SDK is a build tool, not a runtime account dependency. Set ANDROID_JAR to the installed platform's android.jar and ANDROID_BUILD_TOOLS to its build-tools directory. Run `bash scripts/build-android.sh`. It compiles MainActivity.java, packages web assets, dexes and aligns the APK. There is no base APK input.

Signing is separate: provide SIGNING_KEYSTORE and SIGNING_PASSWORD_FILE paths to your own private encrypted keystore and password file. They are deliberately not included. The script signs with Android apksigner and verifies v1/v2/v3 signatures. Keep your keystore, password and alias backed up privately; losing the key prevents compatible updates. Future updates must keep the same application ID and signing key and increase versionCode in android/AndroidManifest.xml.

Display name: Zunora English.

Application ID: com.zunora.english.independent. This differs from the legacy app so both can be installed together. This avoids uninstalling or deleting old progress during testing. Progress must be exported from the old app and imported here; this project cannot access another app's private storage. Browser export/import was tested; the installed old APK's export capability and Android document-picker flow still require device confirmation.

## External services and limits
- Tutor and Writing: optional Pollinations Classic anonymous API. No account/key. One request per 45 seconds per IP, best effort, no guarantee. A 402 is a free-limit/unavailable state, never an instruction to pay. Each action asks before sharing text. Do not send private data. Service and model providers can process/cache text, potentially for up to 30 days. See https://github.com/pollinations/pollinations/blob/master/APIDOCS.md , https://pollinations.ai/terms and https://pollinations.ai/privacy . AI feedback is unverified, not a certified assessment.
- Dictionary definitions: optional https://dictionaryapi.dev/ . Local meanings and IPA remain usable if the service fails. No guaranteed quota or availability is promised.
- Voices: Android's installed TextToSpeech service; its downloaded voices/settings may use network. Browser recognition support varies and may send audio to the browser's recognition provider. Recognition text matching is not an objective pronunciation score.
- Account sync is not provided. Profiles are local, not remote identities. No email password is requested.

## Source layout
web/app.js: formatted existing UI/application code, preserving the current design and course content. Some inert legacy SDK code remains in this file; it is not a clean-room rewrite or the original component source checkout. Active auth/database/AI adapters use web/local-adapters.js. Startup provider gating/session telemetry and badge rendering are removed. Original provider publishable key is removed. A strict CSP and native request allowlist reject nonlocal traffic except the two explicit free-service endpoints. web/index.html contains the additional learning features. All are editable without an account or subscription.

web/clips: packaged videos and thumbnails. web/fonts: locally bundled fonts under SIL OFL; license texts included. Course/dictionary content is embedded in index.html/app.js. Curriculum JSON authoring snapshots are in content/. Duplicate unused web data snapshots are omitted from this archive. scripts/test-browser.js and test-backup.js contain regression tests using Puppeteer; install puppeteer-core for those development tests. The app itself has no npm runtime dependency.

## Known limits before a production release
No Android emulator/device installation has been tested in this environment. Native video streaming of bundled assets, TextToSpeech, backup document picker and import must be checked on a real Android device. The browser version passed route and clip tests. Android WebView speech recognition may be unavailable; it must not claim recording or pronunciation scoring works when unsupported. Notifications are best-effort in-app/browser reminders, not guaranteed background alarms.

## تسليم المشروع بالمصري
1. التطبيق المستقل بيتثبت جنب القديم. متحذفيش القديم قبل ما ننقل التقدم ونتأكد منه.
2. لتشغيل الموقع على كمبيوتر: نزّلي Python، وافتحي Terminal في مجلد المشروع وشغلي الأمر الموجود فوق.
3. لتحديث أندرويد بعد كده: عدلي الملفات في web، زودي versionCode، وابني بالأمر الموجود فوق بنفس مفتاح التوقيع. المفتاح مش جوه ملفات المشروع.
4. الذكاء الاصطناعي اختياري وخارجي ومجاني بحدود. لو وقف، الدروس والفيديوهات والقاموس المحلي يكملوا.
5. ملكية مفتاح التوقيع لسه محتاجة تسليم خاص وآمن. متبعتيش باسوردات أو مفاتيح في الشات.
