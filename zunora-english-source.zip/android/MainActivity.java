package com.zunora.english;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.net.Uri;
import android.content.Intent;
import android.database.Cursor;
import android.provider.OpenableColumns;
import java.io.*;
public class MainActivity extends Activity {
 private WebView web;
 private ValueCallback<Uri[]> chooser;
 private static final int IMPORT=12,EXPORT=13;
 private byte[] pending;
 private android.speech.tts.TextToSpeech tts;
 @Override public void onCreate(Bundle b){super.onCreate(b);tts=new android.speech.tts.TextToSpeech(this,new android.speech.tts.TextToSpeech.OnInitListener(){public void onInit(int status){if(status==0)tts.setLanguage(java.util.Locale.US);}});web=new WebView(this);setContentView(web);web.setBackgroundColor(0xff050907);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);s.setAllowFileAccess(true);s.setAllowFileAccessFromFileURLs(false);s.setAllowUniversalAccessFromFileURLs(false);web.addJavascriptInterface(new Bridge(),"ZunoraNative");web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !"appassets.androidplatform.net".equals(r.getUrl().getHost());}@Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){Uri u=r.getUrl();if("appassets.androidplatform.net".equals(u.getHost())){String p=u.getPath();try{String f=p.equals("/")?"index.html":p.substring(1);if(f.contains(".."))throw new IOException();String mime=f.endsWith(".html")?"text/html":f.endsWith(".js")?"text/javascript":f.endsWith(".css")?"text/css":f.endsWith(".mp4")?"video/mp4":f.endsWith(".jpg")?"image/jpeg":f.endsWith(".json")?"application/json":"application/octet-stream";return new WebResourceResponse(mime,"UTF-8",getAssets().open(f));}catch(Exception e){return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",null,new ByteArrayInputStream(new byte[0]));}}if(!"text.pollinations.ai".equals(u.getHost())&&!"api.dictionaryapi.dev".equals(u.getHost()))return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",null,new ByteArrayInputStream(new byte[0]));return null;}});
 web.setWebChromeClient(new WebChromeClient(){
 @Override public boolean onJsAlert(WebView v,String url,String message,final JsResult result){new android.app.AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("OK",(d,w)->result.confirm()).setOnCancelListener(d->result.cancel()).show();return true;}
 @Override public boolean onJsConfirm(WebView v,String url,String message,final JsResult result){new android.app.AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("Continue",(d,w)->result.confirm()).setNegativeButton("Cancel",(d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show();return true;}
 @Override public boolean onJsPrompt(WebView v,String url,String message,String value,final JsPromptResult result){final android.widget.EditText field=new android.widget.EditText(MainActivity.this);field.setText(value);new android.app.AlertDialog.Builder(MainActivity.this).setMessage(message).setView(field).setPositiveButton("Save",(d,w)->result.confirm(field.getText().toString())).setNegativeButton("Cancel",(d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show();return true;}
@Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> cb,FileChooserParams p){if(chooser!=null)chooser.onReceiveValue(null);chooser=cb;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,IMPORT);return true;}});web.loadUrl("https://appassets.androidplatform.net/index.html#/");}
 public class Bridge {@JavascriptInterface public void speak(String text){if(tts!=null)tts.speak(text,android.speech.tts.TextToSpeech.QUEUE_FLUSH,null,"zunora");} @JavascriptInterface public void stopVoice(){if(tts!=null)tts.stop();} @JavascriptInterface public void exportProgress(String data){pending=data.getBytes(java.nio.charset.StandardCharsets.UTF_8);runOnUiThread(new Runnable(){public void run(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"zunora-progress.json");startActivityForResult(i,EXPORT);}});}}
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==IMPORT&&chooser!=null){chooser.onReceiveValue(c==RESULT_OK&&d!=null?new Uri[]{d.getData()}:null);chooser=null;}if(r==EXPORT&&c==RESULT_OK&&d!=null&&pending!=null){try(OutputStream o=getContentResolver().openOutputStream(d.getData())){o.write(pending);}catch(Exception e){android.widget.Toast.makeText(this,"Backup could not be saved",1).show();}pending=null;}}
 @Override public void onBackPressed(){web.evaluateJavascript("history.back()",null);}
}
