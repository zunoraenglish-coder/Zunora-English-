// Local-only profiles and data adapter. No remote account or password.
const localListeners=new Set();
let localUser=JSON.parse(localStorage.getItem('zunora-local-profile')||'null');
const localAuth={
 async signIn(){let name=prompt('Local profile name',localUser?.name||'');if(!name?.trim())return null;let profiles=JSON.parse(localStorage.getItem('zunora-local-profiles')||'{}');let id=profiles[name.trim()]||('local-'+crypto.randomUUID());profiles[name.trim()]=id;localStorage.setItem('zunora-local-profiles',JSON.stringify(profiles));localUser={id,name:name.trim(),email:'',isLocal:true};localStorage.setItem('zunora-local-profile',JSON.stringify(localUser));localStorage.setItem('__whacka_user_id',id);localListeners.forEach(f=>f(localUser));return localUser;},
 signOut(){localUser=null;localStorage.removeItem('zunora-local-profile');localStorage.removeItem('__whacka_user_id');localListeners.forEach(f=>f(null));},getCurrentUser(){return localUser},isAuthenticated(){return !!localUser},onAuthChange(f){localListeners.add(f);f(localUser);return()=>localListeners.delete(f)},isAppOwner(){return false},getToken(){return null}
};
function localRows(c){if(c==="progress"){let key=localUser?"english-sahla-cache-v2:"+localUser.id:"english-sahla-guest-v2";let saved=JSON.parse(localStorage.getItem(key)||"null");if(saved)return {me:saved};}return JSON.parse(localStorage.getItem('zunora-records-'+(localUser?.id||'guest')+'-'+c)||'{}')}
function saveRows(c,r){localStorage.setItem('zunora-records-'+(localUser?.id||'guest')+'-'+c,JSON.stringify(r))}
const localDb={async get(c,id){return localRows(c)[id]||null},async select(c,filters={},options={}){return Object.values(localRows(c)).filter(r=>Object.entries(filters).every(([k,v])=>r[k]===v)).sort((a,b)=>(a.createdAt||'').localeCompare(b.createdAt||''))},async insert(c,data,id){id=id||crypto.randomUUID();let rows=localRows(c);rows[id]={...data,id};saveRows(c,rows);return rows[id]},async upsert(c,data,id='me'){let rows=localRows(c);rows[id]={...rows[id],...data,id};saveRows(c,rows);return rows[id]},async update(c,id,data){return this.upsert(c,data,id)},async delete(c,id){let rows=localRows(c);delete rows[id];saveRows(c,rows);return true}};
async function freeText(messages,json=false){
 if(!confirm('Free external AI: Pollinations. Text leaves this device and may be cached. Do not send private data. One request per 45 seconds, no availability guarantee. Continue?'))throw Error('Cancelled');
 let next=Number(localStorage.getItem('zunora-ai-next')||0);if(Date.now()<next)throw Error('Free limit: wait '+Math.ceil((next-Date.now())/1000)+' seconds');
 localStorage.setItem('zunora-ai-next',Date.now()+46000);
 let controller=new AbortController(),timer=setTimeout(()=>controller.abort(),60000);
 try{let r=await fetch('https://text.pollinations.ai/',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages,json}),signal:controller.signal});if(!r.ok)throw Error('Free AI unavailable or rate-limited. Try later.');let text=await r.text();if(json){let clean=text.replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,'');return{text,json:JSON.parse(clean)}}return{text}}finally{clearTimeout(timer)}
}
const freeAi={async chat({system,messages}){return freeText([{role:'system',content:system},...messages])},async run(prompt,options={}){return freeText([{role:'user',content:prompt}],!!options.json)}};
window.zunoraLocal={auth:localAuth,db:localDb,ai:freeAi};

if(window.ZunoraNative){window.SpeechSynthesisUtterance=function(text){this.text=text;};window.speechSynthesis={getVoices:()=>[],cancel:()=>ZunoraNative.stopVoice(),speak:u=>ZunoraNative.speak(u.text),pause:()=>ZunoraNative.stopVoice(),resume:()=>{},speaking:false};}
