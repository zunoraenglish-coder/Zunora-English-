const fs=require('fs'),acorn=require('acorn'),esbuild=require('esbuild');let h=fs.readFileSync('/tmp/zunora/patched.html','utf8'),tag='<script type="module">',start=h.indexOf(tag)+tag.length,end=h.indexOf('</script>',start),js=h.slice(start,end),ast=acorn.parse(js,{ecmaVersion:'latest',sourceType:'module'}),ed=[];
for(let n of ast.body)if(n.type==='VariableDeclaration')for(let d of n.declarations)if(['br','Ui','Eb'].includes(d.id.name))ed.push([d.init.start,d.init.end,({br:'window.zunoraLocal.auth',Ui:'window.zunoraLocal.db',Eb:'window.zunoraLocal.ai'})[d.id.name]]);
for(let [a,b,t]of ed.sort((a,b)=>b[0]-a[0]))js=js.slice(0,a)+t+js.slice(b);
// Remove remote-provider startup auth bootstrap. Local adapters own all session state.
js=js.replace('try{Jv()}catch{}Te=BN();Gv(', 'try{}catch{}Te=null;(()=>{} )(');
js=js.replace(/sb_publishable_[A-Za-z0-9_-]+/g,'').replace(/https:\/\/(?:api\.whacka\.app|english-sahla-ke0v\.whacka\.app)/g,'https://disabled.invalid');
fs.writeFileSync('/tmp/zunora-standalone/web/app-original.js',js);
let built=esbuild.transformSync(js,{minify:false,treeShaking:true,format:'esm',target:'es2020'}).code;
built=built.replaceAll('Create a free account to sign in and keep your progress safe.','Use a local profile. Progress stays on this device.').replaceAll('Sign up / Sign in','Local profile').replaceAll('Sign in to save','Local profile');fs.writeFileSync('/tmp/zunora-standalone/web/app.js',built);
h=h.slice(0,start-tag.length)+'<script src="local-adapters.js"></script>\n<script type="module" src="app.js"></script>'+h.slice(end+9);
h=h.replace('https://zunora.codeberg.page/clips/','clips/');
// Remove externally hosted fonts and social preview images. Native system fonts preserve layout fallbacks.
h=h.replace(/<link[^>]*(?:fonts\.googleapis|fonts\.gstatic)[^>]*>/g,'').replace(/@import["'][^"']*fonts\.googleapis[^"']*["'];/g,'');h=h.replace(/<meta[^>]*https:\/\/api\.whacka\.app[^>]*>/g,'');
h=h.replace('<head>','<head>\n<meta http-equiv="Content-Security-Policy" content="default-src \'self\' data: blob:; script-src \'self\' \'unsafe-inline\'; style-src \'self\' \'unsafe-inline\'; img-src \'self\' data: blob:; media-src \'self\' blob:; connect-src \'self\' https://text.pollinations.ai https://api.dictionaryapi.dev; frame-src \'none\'; object-src \'none\'">');
h=h.replace(/https:\/\/zunora-app\.surge\.sh\//g,'#');
h=h.replace(/Create a free account to sign in and keep your progress safe\./g,'Use a local profile. Progress stays on this device; export a backup to move it.').replace(/Sign up \/ Sign in/g,'Local profile').replace(/Sign in to save your progress/g,'Local profile · saved on this device');
h=h.replace(/Sign up \/ Sign in/g,'Local profile');
// Include local-profile and generic local-DB keys in the progress-only export.
h=h.replace('return k === "english-sahla-guest-v2"','return /^(?:zunora-local-profile|zunora-local-profiles|zunora-records-[A-Za-z0-9_-]+)$/.test(k) || k === "english-sahla-guest-v2"');
fs.writeFileSync('/tmp/zunora-standalone/web/index.html',h);console.log('Independent adapter project created, same UI bundle retained');
