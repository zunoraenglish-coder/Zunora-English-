#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${ANDROID_JAR:?Set ANDROID_JAR to Android platform android.jar}"
: "${ANDROID_BUILD_TOOLS:?Set ANDROID_BUILD_TOOLS to SDK build-tools directory}"
mkdir -p build/classes build/dex
javac -source 8 -target 8 -classpath "$ANDROID_JAR" -d build/classes android/MainActivity.java
"$ANDROID_BUILD_TOOLS/d8" --lib "$ANDROID_JAR" --min-api 23 --output build/dex build/classes/com/zunora/english/*.class
"$ANDROID_BUILD_TOOLS/aapt" package -f -M android/AndroidManifest.xml -I "$ANDROID_JAR" -A web -F build/base.apk
cp build/base.apk build/unsigned.apk
(cd build/dex && zip -q -j ../unsigned.apk classes.dex)
"$ANDROID_BUILD_TOOLS/zipalign" -f 4 build/unsigned.apk build/aligned.apk
if [[ -n "${SIGNING_KEYSTORE:-}" ]];then
 : "${SIGNING_PASSWORD_FILE:?Set path, never password in command line}"
 "$ANDROID_BUILD_TOOLS/apksigner" sign --ks "$SIGNING_KEYSTORE" --ks-pass "file:$SIGNING_PASSWORD_FILE" --out build/zunora.apk build/aligned.apk
 "$ANDROID_BUILD_TOOLS/apksigner" verify --verbose build/zunora.apk
else
 echo 'Unsigned aligned APK ready. Supply signing keystore separately to sign.'
fi
